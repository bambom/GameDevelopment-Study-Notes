#include <jni.h>
#include <android/log.h>
#include <Substrate/CydiaSubstrate.h>
#include <memory.h>
#include <dlfcn.h>
#include <cstdio>
#include <cstdlib>
#import "Utils.h"


//[Address(RVA="0x707220", Offset="0x707220")] public override int get_energy()
 int(*get_energy_orig)(void *_this) = NULL;
 int get_energy_mod(void*_this){
	 //int result = get_energy_orig(_this);
	 return 10000;
 }

 
 //[Address(RVA="0x3AACAC", Offset="0x3AACAC")]public int get_gems()
 
 int(*get_gems_orig)(void *_this) = NULL;
 int get_gems_mod(void *_this){
	return 888888888;
}

//[Address(RVA="0x7097B4", Offset="0x7097B4")]public bool get_skill_ready()
 
bool(*get_skill_ready_orig)() = NULL;
bool get_skill_ready_mod(){
	return true;;
}

//void HurtArmor(int damage, GameObject source_object)
 void(*HurtArmor_orig)(int damage,void *source_object) = NULL;
 void HurtArmor_mod(int damage,void *source_object){
	 if(damage<0){
		 damage = 0-damage;
	 }
	 return HurtArmor_orig(damage,source_object);
 }


//void HurtHp(int damage, GameObject source_object)
 void(*HurtHp_orig)(int damage,void *source_object) = NULL;
 void HurtHp_mod(int damage,void *source_object){
	 if(damage<0){
		 damage = 0-damage;
	 }
	 return HurtHp_orig(damage,source_object);
 }
 
//[Address(RVA="0x6FC4BC", Offset="0x6FC4BC")]protected bool get__autoAttack()
 
 bool(*get__autoAttack_orig)(void *_this) = NULL;
bool get__autoAttack_mod(void *_this){
	return true;;
}

//[Address(RVA="0x3ACBAC", Offset="0x3ACBAC")]public bool get_unlock_debug_tool()

bool(*get_unlock_debug_tool_orig)(void *_this)=NULL;
bool get_unlock_debug_tool_mod(void *_this){
	 return true;
 }

__attribute__((constructor))
void libhook_main() {

    while(libBase == 0) { 
        libBase = get_libBase(libName); 
        sleep(1); 
    }
	MSHookFunction((void *)getRealOffset(0x3ACBAC), (void *)get_unlock_debug_tool_mod, (void **) &get_unlock_debug_tool_orig);
	MSHookFunction((void *)getRealOffset(0x6FC4BC), (void *)get__autoAttack_mod, (void **) &get__autoAttack_orig);
	MSHookFunction((void *)getRealOffset(0x3AACAC), (void *)get_gems_mod, (void **) &get_gems_orig);			//有效
	MSHookFunction((void *)getRealOffset(0x7097B4), (void *)get_skill_ready_mod, (void **) &get_skill_ready_orig);  //有效		
	MSHookFunction((void *)getRealOffset(0x707220), (void *)get_energy_mod, (void **) &get_energy_orig);   	//有效
    MSHookFunction((void *)getRealOffset(0x815410), (void *)HurtArmor_mod, (void **) &HurtArmor_orig);		//有效
    MSHookFunction((void *)getRealOffset(0x815554), (void *)HurtHp_mod, (void **) &HurtHp_orig);			//有效
}
