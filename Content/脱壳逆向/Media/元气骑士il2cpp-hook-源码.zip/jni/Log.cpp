#include "Log.h"


#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdint.h>

#include <jni.h>
#include <android/log.h>
#include <stdarg.h>


#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif



